class Pokemon:
    """Representa un Pokémon y sus estadísticas de entrenamiento."""

    _cantidad_creados = 0

    def __init__(self, nombre: str, tipo: str, ataque: int,
                 defensa: int, salud: int, nivel: int = 1):
        self.nombre = nombre
        self.tipo = tipo
        self.nivel = nivel
        self.ataque = ataque
        self.defensa = defensa
        self.salud = salud
        Pokemon._cantidad_creados += 1
        print(f"✨ ¡{self.nombre} ({self.tipo}) se ha unido al equipo!")

    def __del__(self):
        # El momento exacto de ejecución depende del recolector de memoria.
        nombre = getattr(self, "nombre", "Pokémon")
        print(f"🕊️ {nombre} ha sido liberado.")

    def entrenar(self, *mejoras):
        """Sube un nivel y aplica mejoras opcionales: ataque, defensa, salud.

        Sin argumentos aplica +2 a ataque, +1 a defensa y +5 a salud.
        Con argumentos, cada valor numérico se suma a una estadística
        en el orden ataque, defensa, salud. Se aceptan de uno a tres valores.
        """
        if len(mejoras) > 3:
            raise ValueError("Indica como máximo 3 mejoras: ataque, defensa y salud.")
        if any(not isinstance(valor, int) or valor < 0 for valor in mejoras):
            raise ValueError("Las mejoras deben ser enteros positivos o cero.")

        self.nivel += 1
        if not mejoras:
            mejoras = (2, 1, 5)

        atributos = ("ataque", "defensa", "salud")
        for atributo, valor in zip(atributos, mejoras):
            setattr(self, atributo, getattr(self, atributo) + valor)

        print(f"💪 {self.nombre} entrenó y alcanzó el nivel {self.nivel}.")

    def mostrar_info(self):
        """Muestra las estadísticas actuales."""
        print(
            f"\n📋 {self.nombre} | Tipo: {self.tipo} | Nivel: {self.nivel}\n"
            f"   Ataque: {self.ataque} | Defensa: {self.defensa} | Salud: {self.salud}\n"
            f"   Poder total: {self.calcular_poder()}"
        )

    def calcular_poder(self):
        """Calcula un indicador sencillo de poder total."""
        return self.nivel * 10 + self.ataque + self.defensa + self.salud

    def atacar(self, objetivo):
        """Ataca otro Pokémon; el daño mínimo es 1."""
        if objetivo is self:
            print("⚠️ Un Pokémon no puede atacarse a sí mismo.")
            return
        if objetivo.salud <= 0:
            print(f"⚠️ {objetivo.nombre} ya no puede combatir.")
            return

        danio = max(1, self.ataque - objetivo.defensa)
        objetivo.salud = max(0, objetivo.salud - danio)
        print(
            f"⚔️ {self.nombre} ataca a {objetivo.nombre} e inflige {danio} "
            f"de daño. Salud restante: {objetivo.salud}."
        )

    @classmethod
    def total_pokemons(cls):
        """Muestra cuántos Pokémon se han creado durante la ejecución."""
        print(f"🧮 Pokémon creados en esta sesión: {cls._cantidad_creados}")
        return cls._cantidad_creados
